import json
import numpy as np
import os
from collections import defaultdict


np.random.seed(123)

folder = './baby/'
core = 5
train_json = json.load(open(folder+"%d-core/train.json"%core))
test_json = json.load(open(folder+"%d-core/test.json"%core))
val_json = json.load(open(folder+"%d-core/val.json"%core))
for u, items in test_json.items():
    for j in items:
        if j not in train_json[u]:
            train_json[u].append(j)
for u, items in val_json.items():
    for j in items:
        if j not in train_json[u]:
            train_json[u].append(j)
for u ,items in train_json.items():
    remove = np.random.choice(len(items),int(0.2*len(items)),replace=False)
    train = [i for i in list(range(len(items))) if i not in remove]
    train_json[u] = [items[i] for i in train]
train_set, test_set, val_set = {}, {}, {}
for u, items in train_json.items():
    if len(items) < 10:
        testval = np.random.choice(len(items), 2, replace=False)
    else:
        testval = np.random.choice(len(items), int(len(items) * 0.2), replace=False)
    test = testval[:len(testval) // 2]
    val = testval[len(testval) // 2:]
    train = [i for i in list(range(len(items))) if i not in testval]
    train_set[u] = [items[idx] for idx in train]
    val_set[u] = [items[idx] for idx in val.tolist()]
    test_set[u] = [items[idx] for idx in test.tolist()]
with open(folder + '%d-core/train.json'%core, 'w') as f:
    json.dump(train_json, f)
with open(folder + '%d-core/val.json'%core, 'w') as f:
    json.dump(val_json, f)
with open(folder + '%d-core/test.json'%core, 'w') as f:
    json.dump(test_json, f)
# test = testval[:len(testval)//2]
# file = open(folder + "meta-data/%d-core.json"%core)
# jsons = []
# for line in file.readlines():
#     jsons.append(json.loads(line))

# ui = json.load(open(folder + "%d-core/user-item-dict.json"%core))
#
# iu = defaultdict(list)
# for u, items in ui.items():
#     for i in items:
#         iu[i].append(int(u))
#
# testval = np.random.choice(len(iu), int(0.2*len(iu)), replace=False).tolist()
# test = testval[:len(testval)//2]
# val = testval[len(testval)//2:]
#
# train_ui = {}
# test_ui = {}
# val_ui = {}
# for u, items in ui.items():
#     train_ui[u] = [i for i in items if i not in testval]
#     val_ui[u] = [i for i in items if i in val]
#     test_ui[u] = [i for i in items if i in test]
#
# if not os.path.exists(folder+'0-core'):
#     os.mkdir(folder+'0-core')
#
# json.dump(val_ui, open(folder+'0-core/val.json', 'w'))
# json.dump(test_ui, open(folder+'0-core/test.json', 'w'))
# json.dump(train_ui, open(folder+'0-core/train.json', 'w'))
