# CAMR

PyTorch implementation for Towards User-specific Multimodal Recommendation via Cross-Modal Attention-enhanced Graph Convolution Network

<p align="center">
<img src="./CAMR.png" alt="CAMR" width="1000" height="555"/>
</p>

## Dependencies

- Python 3.8
- torch==1.12.0
- scikit-learn==1.1.3



## Dataset Preparation

- Download **5-core reviews data**, **meta data**, and **image features** from [Amazon product dataset](http://jmcauley.ucsd.edu/data/amazon/links.html). Put data into the directory `data/meta-data/`.

- Install [sentence-transformers](https://www.sbert.net/docs/installation.html) and download [pretrained models](https://www.sbert.net/docs/pretrained_models.html) to extract textual features. Unzip pretrained model into the directory `sentence-transformers/`:

  ```
  ├─ data/: 
      ├── sports/
      	├── meta-data/
      		├── image_features_Sports_and_Outdoors.b
      		├── meta-Sports_and_Outdoors.json.gz
      		├── reviews_Sports_and_Outdoors_5.json.gz
      ├── sentence-transformers/
          	├── stsb-roberta-large
  ```

- Run `python build_data.py` to preprocess data.

- We provide processed data [Baidu Yun](https://pan.baidu.com/s/1xCFkudYyyVo4orMW5inE_A) (access code: kt4p).

## Usage

Start training and inference as:

```
cd codes
python main.py --dataset baby --alpha 0.1 --beta 0.03

python main.py --dataset sports --alpha 0.1 --beta 0.1

python main.py --dataset clothing --alpha 0.03 --beta 0.03
```






## Acknowledgement

The structure of this code is largely based on [LATTICE](https://github.com/CRIPAC-DIG/LATTICE). Thank for their work.

