import os
import numpy as np
from time import time
import scipy.sparse as sp
import torch
import torch.nn as nn
import torch.sparse as sparse
import torch.nn.functional as F
import random
from utility.parser import parse_args

import torch.optim as optim

args = parse_args()
def build_knn_neighbourhood(adj, topk):
    knn_val, knn_ind = torch.topk(adj, topk, dim=-1)
    weighted_adjacency_matrix = (torch.zeros_like(adj)).scatter_(-1, knn_ind, knn_val)
    return weighted_adjacency_matrix
def compute_normalized_laplacian(adj):
    rowsum = torch.sum(adj, -1)
    d_inv_sqrt = torch.pow(rowsum, -0.5)
    d_inv_sqrt[torch.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = torch.diagflat(d_inv_sqrt)
    L_norm = torch.mm(torch.mm(d_mat_inv_sqrt, adj), d_mat_inv_sqrt)
    return L_norm
def build_sim(context):
    context_norm = context.div(torch.norm(context, p=2, dim=-1, keepdim=True))
    sim = torch.mm(context_norm, context_norm.transpose(1, 0))
    return sim
def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)


def normalized_adj_single(adj):
    rowsum = np.array(adj.sum(1))

    d_inv = np.power(rowsum, -1).flatten()
    d_inv[np.isinf(d_inv)] = 0.
    d_mat_inv = sp.diags(d_inv)

    norm_adj = d_mat_inv.dot(adj)
    # norm_adj = adj.dot(d_mat_inv)
    #print('generate single-normalized adjacency matrix.')
    return norm_adj.tocoo()


class CAMR(nn.Module):
    def __init__(self, n_users, n_items, embedding_dim, weight_size, dropout_list, image_feats, text_feats):
        super().__init__()
        self.n_users = n_users
        self.n_items = n_items
        self.embedding_dim = embedding_dim
        self.weight_size = weight_size
        self.n_ui_layers =args.n_ui_layers
        self.weight_size = [self.embedding_dim] + self.weight_size
        self.user_embedding = nn.Embedding(n_users, self.embedding_dim)
        self.item_id_embedding = nn.Embedding(n_items, self.embedding_dim)
        nn.init.xavier_uniform_(self.user_embedding.weight)
        nn.init.xavier_uniform_(self.item_id_embedding.weight)

        if args.cf_model == 'ngcf':
            self.GC_Linear_list = nn.ModuleList()
            self.Bi_Linear_list = nn.ModuleList()
            self.dropout_list = nn.ModuleList()
            for i in range(self.n_ui_layers):
                self.GC_Linear_list.append(nn.Linear(self.weight_size[i], self.weight_size[i+1]))
                self.Bi_Linear_list.append(nn.Linear(self.weight_size[i], self.weight_size[i+1]))
                self.dropout_list.append(nn.Dropout(dropout_list[i]))

        self.image_embedding = nn.Embedding.from_pretrained(torch.Tensor(image_feats), freeze=False)
        self.text_embedding = nn.Embedding.from_pretrained(torch.Tensor(text_feats), freeze=False)
        if os.path.exists('../data/%s/image_adj_%d.pt'%(args.dataset, args.topk)):
            image_adj = torch.load('../data/%s/image_adj_%d.pt'%(args.dataset, args.topk))
        else:
            image_adj = build_sim(self.image_embedding.weight.detach())
            image_adj = build_knn_neighbourhood(image_adj, topk=args.topk)
            image_adj = compute_normalized_laplacian(image_adj)
            torch.save(image_adj, '../data/%s/image_adj_%d.pt'%(args.dataset, args.topk))

        if os.path.exists('../data/%s/text_adj_%d.pt'%(args.dataset, args.topk)):
            text_adj = torch.load('../data/%s/text_adj_%d.pt'%(args.dataset, args.topk))
        else:
            text_adj = build_sim(self.text_embedding.weight.detach())
            text_adj = build_knn_neighbourhood(text_adj, topk=args.topk)
            text_adj = compute_normalized_laplacian(text_adj)
            torch.save(text_adj, '../data/%s/text_adj_%d.pt'%(args.dataset, args.topk))

        self.text_original_adj = text_adj.cuda()
        self.image_original_adj = image_adj.cuda()
        self.image_trs = nn.Linear(image_feats.shape[1], args.feat_embed_dim)
        self.text_trs = nn.Linear(text_feats.shape[1], args.feat_embed_dim)
        self.att_trs = nn.Linear(args.feat_embed_dim, 1)
        self.modal_weight = nn.Parameter(torch.Tensor([0.5, 0.5]))
        self.softmax = nn.Softmax(dim=-1)
        self.Softmax = nn.Softmax(dim=0)
        #cross-attention
        self.scale = args.feat_embed_dim ** -0.5

    def cross_att(self,feat1,feat2,feat3):
        q = F.normalize(feat1,p=2,dim=1)
        k = F.normalize(feat2,p=2,dim=1)
        v = feat3
        # att_weight = torch.mul(q,k)
        # att_weight = torch.exp(self.att_trs(att_weight) * self.scale)
        # out = att_weight * v
        att_weights = torch.mm(q, k.transpose(1, 0))
        att_weights = att_weights * self.scale
        att_weights = torch.exp(att_weights)
        out = torch.einsum('ii,ij -> ij', att_weights, v)

        return out

    def forward(self, adj,  build_item_graph=False):
        image_feat = self.image_trs(self.image_embedding.weight)
        text_feat = self.text_trs(self.text_embedding.weight)
        image_emb = self.item_id_embedding.weight + F.normalize(self.item_id_embedding.weight,p=2,dim=1)
        text_emb = self.item_id_embedding.weight + F.normalize(self.item_id_embedding.weight,p=2,dim=1)
        for i in range(args.n_layers):
            image_emb = torch.mm(self.image_original_adj, image_emb)
            text_emb = torch.mm(self.text_original_adj, text_emb)
        #cross_attention
        all_v_feat = torch.cat((self.user_embedding.weight, image_feat),dim=0)
        all_t_feat = torch.cat((self.user_embedding.weight, text_feat),dim=0)
        all_g_feat = torch.cat((self.user_embedding.weight, self.item_id_embedding.weight+ F.normalize(self.item_id_embedding.weight,p=2,dim=1)), dim=0)#
        all_v_feat = torch.sparse.mm(adj, all_v_feat)
        all_t_feat = torch.sparse.mm(adj, all_t_feat)
        all_g_feat = torch.sparse.mm(adj, all_g_feat)

        u_v_feat, i_feat = torch.split(all_v_feat, [self.n_users, self.n_items], dim=0)
        u_t_feat, _ = torch.split(all_t_feat, [self.n_users, self.n_items], dim=0)
        u_g_feat, _ = torch.split(all_g_feat, [self.n_users, self.n_items], dim=0)
        # att_v = torch.mul(u_v_feat,u_v_feat)*self.scale
        # att_v = torch.sum(att_v,dim=1).unsqueeze(-1)
        # att_t = torch.mul(u_t_feat,u_t_feat)*self.scale
        # att_t = torch.sum(att_t, dim=1).unsqueeze(-1)
        # att_g = torch.mul(u_g_feat, u_g_feat) * self.scale
        # att_g = torch.sum(att_g, dim=1).unsqueeze(-1)
        # att = torch.cat([att_v,att_t,att_g],dim=-1)
        # att = torch.softmax(att,dim=-1)
        #u_feat = att[:,0].unsqueeze(-1)*u_v_feat + att[:,1].unsqueeze(-1)*u_t_feat +att[:,2].unsqueeze(-1)*u_g_feat
        u_feat = torch.stack((u_v_feat, u_t_feat, u_g_feat),dim=1)
        u_feat = u_feat.mean(dim=1, keepdim=False)
        #u_feat = self.cross_att(u_t_feat,u_v_feat,u_g_feat)
        #out = self.cross_att(text_emb,image_emb,self.item_id_embedding.weight)
        i_feat = self.cross_att(text_emb, image_emb, i_feat)
        #weight = F.softmax(weight,dim=-1)
        #i_emb = weight[:,0].unsqueeze(-1)*text_emb + weight[:,1].unsqueeze(-1) * image_emb
        #out_t = self.cross_attention(text_emb,self.item_id_embedding.weight,self.item_id_embedding.weight)
        #out = self.cross_att(text_emb,image_emb,i_feat)
        #out =self.wq(out)
        #ua = torch.norm(self.item_id_embedding.weight, p=2, dim=-1, keepdim=True)
        #out = out/ua
        #ub = F.normalize(self.item_id_embedding.weight,p=2,dim=1)



        if args.cf_model == 'ngcf':
            ego_embeddings = torch.cat((self.user_embedding.weight, self.item_id_embedding.weight+F.normalize(self.item_id_embedding.weight,p=2,dim=1)), dim=0)
            all_embeddings = [ego_embeddings]
            for i in range(self.n_ui_layers):
                side_embeddings = torch.sparse.mm(adj, ego_embeddings)
                sum_embeddings = F.leaky_relu(self.GC_Linear_list[i](side_embeddings))
                bi_embeddings = torch.mul(ego_embeddings, side_embeddings)
                bi_embeddings = F.leaky_relu(self.Bi_Linear_list[i](bi_embeddings))
                ego_embeddings = sum_embeddings + bi_embeddings
                ego_embeddings = self.dropout_list[i](ego_embeddings)
                norm_embeddings = F.normalize(ego_embeddings, p=2, dim=1)
                all_embeddings += [norm_embeddings]
            all_embeddings = torch.stack(all_embeddings, dim=1)
            all_embeddings = all_embeddings.mean(dim=1, keepdim=False)
            u_g_embeddings, i_g_embeddings = torch.split(all_embeddings, [self.n_users, self.n_items], dim=0)
            i_g_embeddings = i_g_embeddings + F.normalize(i_feat, p=2, dim=1)
            return u_g_embeddings+F.normalize(u_feat,p=2,dim=1), i_g_embeddings, i_feat,image_emb,image_emb
        elif args.cf_model == 'lightgcn':
            ego_embeddings = torch.cat((self.user_embedding.weight, self.item_id_embedding.weight+ F.normalize(self.item_id_embedding.weight, p=2, dim=1) ), dim=0)#+ F.normalize(self.item_id_embedding.weight, p=2, dim=1)
            all_embeddings = [ego_embeddings]
            for i in range(self.n_ui_layers):
                side_embeddings = torch.sparse.mm(adj, ego_embeddings)
                all_embeddings += [side_embeddings]
                ego_embeddings = side_embeddings
                #intent_emb = torch.softmax(ego_embeddings)
            #del ego_embeddings, side_embeddings
            all_embeddings = torch.stack(all_embeddings, dim=1)
            all_embeddings = all_embeddings.mean(dim=1, keepdim=False)
            u_g_embeddings, i_g_embeddings = torch.split(all_embeddings, [self.n_users, self.n_items], dim=0)
            i_g_embeddings = i_g_embeddings + F.normalize(i_feat, p=2, dim=1)
            u_g_embeddings = u_g_embeddings + F.normalize(u_feat,p=2,dim=1)
            return u_g_embeddings, i_g_embeddings, image_emb,text_emb
        elif args.cf_model == 'mf':
            return self.user_embedding.weight, self.item_id_embedding.weight

